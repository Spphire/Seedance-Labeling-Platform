from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar, Optional

DESCRIPTOR: _descriptor.FileDescriptor

class LiftCommand(_message.Message):
    __slots__ = ["speed", "step"]
    SPEED_FIELD_NUMBER: ClassVar[int]
    STEP_FIELD_NUMBER: ClassVar[int]
    speed: float
    step: float
    def __init__(self, step: Optional[float] = ..., speed: Optional[float] = ...) -> None: ...

class LiftMove(_message.Message):
    __slots__ = ["height"]
    HEIGHT_FIELD_NUMBER: ClassVar[int]
    height: float
    def __init__(self, height: Optional[float] = ...) -> None: ...

class LiftState(_message.Message):
    __slots__ = ["height"]
    HEIGHT_FIELD_NUMBER: ClassVar[int]
    height: float
    def __init__(self, height: Optional[float] = ...) -> None: ...
