from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar, Optional

DESCRIPTOR: _descriptor.FileDescriptor

class BmsState(_message.Message):
    __slots__ = ["battery_percentage", "is_charging"]
    BATTERY_PERCENTAGE_FIELD_NUMBER: ClassVar[int]
    IS_CHARGING_FIELD_NUMBER: ClassVar[int]
    battery_percentage: int
    is_charging: bool
    def __init__(self, battery_percentage: Optional[int] = ..., is_charging: bool = ...) -> None: ...
