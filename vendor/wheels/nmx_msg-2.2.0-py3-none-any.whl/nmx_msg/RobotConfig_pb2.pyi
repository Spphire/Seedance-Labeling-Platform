from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar, Iterable, Mapping, Optional, Union

DESCRIPTOR: _descriptor.FileDescriptor

class ArmConfig(_message.Message):
    __slots__ = ["base_link", "enabled", "ip", "period", "reset_joint_target", "sub_type", "teleop_enabled", "type"]
    BASE_LINK_FIELD_NUMBER: ClassVar[int]
    ENABLED_FIELD_NUMBER: ClassVar[int]
    IP_FIELD_NUMBER: ClassVar[int]
    PERIOD_FIELD_NUMBER: ClassVar[int]
    RESET_JOINT_TARGET_FIELD_NUMBER: ClassVar[int]
    SUB_TYPE_FIELD_NUMBER: ClassVar[int]
    TELEOP_ENABLED_FIELD_NUMBER: ClassVar[int]
    TYPE_FIELD_NUMBER: ClassVar[int]
    base_link: _containers.RepeatedScalarFieldContainer[float]
    enabled: bool
    ip: str
    period: float
    reset_joint_target: _containers.RepeatedScalarFieldContainer[float]
    sub_type: str
    teleop_enabled: bool
    type: str
    def __init__(self, type: Optional[str] = ..., sub_type: Optional[str] = ..., ip: Optional[str] = ..., reset_joint_target: Optional[Iterable[float]] = ..., period: Optional[float] = ..., enabled: bool = ..., teleop_enabled: bool = ..., base_link: Optional[Iterable[float]] = ...) -> None: ...

class CameraConfig(_message.Message):
    __slots__ = ["camera_list", "enabled", "ids", "ip", "port", "teleop_enabled"]
    CAMERA_LIST_FIELD_NUMBER: ClassVar[int]
    ENABLED_FIELD_NUMBER: ClassVar[int]
    IDS_FIELD_NUMBER: ClassVar[int]
    IP_FIELD_NUMBER: ClassVar[int]
    PORT_FIELD_NUMBER: ClassVar[int]
    TELEOP_ENABLED_FIELD_NUMBER: ClassVar[int]
    camera_list: _containers.RepeatedCompositeFieldContainer[CameraInfo]
    enabled: bool
    ids: _containers.RepeatedScalarFieldContainer[str]
    ip: str
    port: int
    teleop_enabled: bool
    def __init__(self, ids: Optional[Iterable[str]] = ..., camera_list: Optional[Iterable[Union[CameraInfo, Mapping]]] = ..., ip: Optional[str] = ..., port: Optional[int] = ..., enabled: bool = ..., teleop_enabled: bool = ...) -> None: ...

class CameraInfo(_message.Message):
    __slots__ = ["enabled", "has_depth", "id", "motion", "pos", "teleop_enabled"]
    ENABLED_FIELD_NUMBER: ClassVar[int]
    HAS_DEPTH_FIELD_NUMBER: ClassVar[int]
    ID_FIELD_NUMBER: ClassVar[int]
    MOTION_FIELD_NUMBER: ClassVar[int]
    POS_FIELD_NUMBER: ClassVar[int]
    TELEOP_ENABLED_FIELD_NUMBER: ClassVar[int]
    enabled: bool
    has_depth: bool
    id: str
    motion: Motion
    pos: str
    teleop_enabled: bool
    def __init__(self, id: Optional[str] = ..., pos: Optional[str] = ..., has_depth: bool = ..., motion: Optional[Union[Motion, Mapping]] = ..., enabled: bool = ..., teleop_enabled: bool = ...) -> None: ...

class Capability(_message.Message):
    __slots__ = ["teleop_capability"]
    TELEOP_CAPABILITY_FIELD_NUMBER: ClassVar[int]
    teleop_capability: TeleopCapability
    def __init__(self, teleop_capability: Optional[Union[TeleopCapability, Mapping]] = ...) -> None: ...

class ChassisConfig(_message.Message):
    __slots__ = ["enabled", "ip", "port", "teleop_enabled"]
    ENABLED_FIELD_NUMBER: ClassVar[int]
    IP_FIELD_NUMBER: ClassVar[int]
    PORT_FIELD_NUMBER: ClassVar[int]
    TELEOP_ENABLED_FIELD_NUMBER: ClassVar[int]
    enabled: bool
    ip: str
    port: int
    teleop_enabled: bool
    def __init__(self, ip: Optional[str] = ..., port: Optional[int] = ..., enabled: bool = ..., teleop_enabled: bool = ...) -> None: ...

class Component(_message.Message):
    __slots__ = ["arms", "cameras", "chassis", "end_tools", "torso"]
    ARMS_FIELD_NUMBER: ClassVar[int]
    CAMERAS_FIELD_NUMBER: ClassVar[int]
    CHASSIS_FIELD_NUMBER: ClassVar[int]
    END_TOOLS_FIELD_NUMBER: ClassVar[int]
    TORSO_FIELD_NUMBER: ClassVar[int]
    arms: _containers.RepeatedCompositeFieldContainer[ArmConfig]
    cameras: CameraConfig
    chassis: ChassisConfig
    end_tools: _containers.RepeatedCompositeFieldContainer[EndToolConfig]
    torso: TorsoConfig
    def __init__(self, arms: Optional[Iterable[Union[ArmConfig, Mapping]]] = ..., end_tools: Optional[Iterable[Union[EndToolConfig, Mapping]]] = ..., cameras: Optional[Union[CameraConfig, Mapping]] = ..., chassis: Optional[Union[ChassisConfig, Mapping]] = ..., torso: Optional[Union[TorsoConfig, Mapping]] = ...) -> None: ...

class EndToolConfig(_message.Message):
    __slots__ = ["close_width", "enabled", "force", "open_width", "status", "teleop_enabled", "type"]
    CLOSE_WIDTH_FIELD_NUMBER: ClassVar[int]
    ENABLED_FIELD_NUMBER: ClassVar[int]
    FORCE_FIELD_NUMBER: ClassVar[int]
    OPEN_WIDTH_FIELD_NUMBER: ClassVar[int]
    STATUS_FIELD_NUMBER: ClassVar[int]
    TELEOP_ENABLED_FIELD_NUMBER: ClassVar[int]
    TYPE_FIELD_NUMBER: ClassVar[int]
    close_width: int
    enabled: bool
    force: int
    open_width: int
    status: str
    teleop_enabled: bool
    type: str
    def __init__(self, type: Optional[str] = ..., status: Optional[str] = ..., force: Optional[int] = ..., close_width: Optional[int] = ..., open_width: Optional[int] = ..., enabled: bool = ..., teleop_enabled: bool = ...) -> None: ...

class Motion(_message.Message):
    __slots__ = ["lift", "pitch", "roll", "yaw"]
    LIFT_FIELD_NUMBER: ClassVar[int]
    PITCH_FIELD_NUMBER: ClassVar[int]
    ROLL_FIELD_NUMBER: ClassVar[int]
    YAW_FIELD_NUMBER: ClassVar[int]
    lift: bool
    pitch: bool
    roll: bool
    yaw: bool
    def __init__(self, lift: bool = ..., pitch: bool = ..., yaw: bool = ..., roll: bool = ...) -> None: ...

class RobotConfig(_message.Message):
    __slots__ = ["capability", "components", "device_id", "frequency", "ip", "low_pass_filter", "manufacturer", "name", "robot_id", "role", "software_version", "type"]
    CAPABILITY_FIELD_NUMBER: ClassVar[int]
    COMPONENTS_FIELD_NUMBER: ClassVar[int]
    DEVICE_ID_FIELD_NUMBER: ClassVar[int]
    FREQUENCY_FIELD_NUMBER: ClassVar[int]
    IP_FIELD_NUMBER: ClassVar[int]
    LOW_PASS_FILTER_FIELD_NUMBER: ClassVar[int]
    MANUFACTURER_FIELD_NUMBER: ClassVar[int]
    NAME_FIELD_NUMBER: ClassVar[int]
    ROBOT_ID_FIELD_NUMBER: ClassVar[int]
    ROLE_FIELD_NUMBER: ClassVar[int]
    SOFTWARE_VERSION_FIELD_NUMBER: ClassVar[int]
    TYPE_FIELD_NUMBER: ClassVar[int]
    capability: Capability
    components: Component
    device_id: str
    frequency: int
    ip: str
    low_pass_filter: bool
    manufacturer: str
    name: str
    robot_id: str
    role: str
    software_version: str
    type: str
    def __init__(self, name: Optional[str] = ..., robot_id: Optional[str] = ..., type: Optional[str] = ..., manufacturer: Optional[str] = ..., software_version: Optional[str] = ..., device_id: Optional[str] = ..., role: Optional[str] = ..., frequency: Optional[int] = ..., ip: Optional[str] = ..., low_pass_filter: bool = ..., components: Optional[Union[Component, Mapping]] = ..., capability: Optional[Union[Capability, Mapping]] = ...) -> None: ...

class TeleopCapability(_message.Message):
    __slots__ = ["joint", "tcp"]
    JOINT_FIELD_NUMBER: ClassVar[int]
    TCP_FIELD_NUMBER: ClassVar[int]
    joint: bool
    tcp: bool
    def __init__(self, tcp: bool = ..., joint: bool = ...) -> None: ...

class TorsoConfig(_message.Message):
    __slots__ = ["enabled", "teleop_enabled", "torso_motion_type"]
    ENABLED_FIELD_NUMBER: ClassVar[int]
    TELEOP_ENABLED_FIELD_NUMBER: ClassVar[int]
    TORSO_MOTION_TYPE_FIELD_NUMBER: ClassVar[int]
    enabled: bool
    teleop_enabled: bool
    torso_motion_type: Motion
    def __init__(self, torso_motion_type: Optional[Union[Motion, Mapping]] = ..., enabled: bool = ..., teleop_enabled: bool = ...) -> None: ...
