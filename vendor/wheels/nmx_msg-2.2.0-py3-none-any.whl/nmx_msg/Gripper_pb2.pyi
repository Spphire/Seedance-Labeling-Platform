from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar, Optional

DESCRIPTOR: _descriptor.FileDescriptor

class GripperParam(_message.Message):
    __slots__ = ["max_force", "max_width", "min_force", "min_width"]
    MAX_FORCE_FIELD_NUMBER: ClassVar[int]
    MAX_WIDTH_FIELD_NUMBER: ClassVar[int]
    MIN_FORCE_FIELD_NUMBER: ClassVar[int]
    MIN_WIDTH_FIELD_NUMBER: ClassVar[int]
    max_force: float
    max_width: float
    min_force: float
    min_width: float
    def __init__(self, max_width: Optional[float] = ..., min_width: Optional[float] = ..., max_force: Optional[float] = ..., min_force: Optional[float] = ...) -> None: ...
