from nmx_msg import Joint_pb2 as _Joint_pb2
from nmx_msg import Pose_pb2 as _Pose_pb2
from nmx_msg import Vec_pb2 as _Vec_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar, Iterable, Mapping, Optional, Union

DESCRIPTOR: _descriptor.FileDescriptor

class UmiPose(_message.Message):
    __slots__ = ["angular_vel", "linear_vel", "pose"]
    ANGULAR_VEL_FIELD_NUMBER: ClassVar[int]
    LINEAR_VEL_FIELD_NUMBER: ClassVar[int]
    POSE_FIELD_NUMBER: ClassVar[int]
    angular_vel: _Vec_pb2.Vec3
    linear_vel: _Vec_pb2.Vec3
    pose: _Pose_pb2.Pose3
    def __init__(self, pose: Optional[Union[_Pose_pb2.Pose3, Mapping]] = ..., linear_vel: Optional[Union[_Vec_pb2.Vec3, Mapping]] = ..., angular_vel: Optional[Union[_Vec_pb2.Vec3, Mapping]] = ...) -> None: ...

class UmiState(_message.Message):
    __slots__ = ["joints"]
    JOINTS_FIELD_NUMBER: ClassVar[int]
    joints: _containers.RepeatedCompositeFieldContainer[_Joint_pb2.JointState]
    def __init__(self, joints: Optional[Iterable[Union[_Joint_pb2.JointState, Mapping]]] = ...) -> None: ...
