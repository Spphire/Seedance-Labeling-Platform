from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar, Optional

DESCRIPTOR: _descriptor.FileDescriptor

class LightCmd(_message.Message):
    __slots__ = ["brightness"]
    BRIGHTNESS_FIELD_NUMBER: ClassVar[int]
    brightness: float
    def __init__(self, brightness: Optional[float] = ...) -> None: ...

class LightState(_message.Message):
    __slots__ = ["brightness"]
    BRIGHTNESS_FIELD_NUMBER: ClassVar[int]
    brightness: float
    def __init__(self, brightness: Optional[float] = ...) -> None: ...
