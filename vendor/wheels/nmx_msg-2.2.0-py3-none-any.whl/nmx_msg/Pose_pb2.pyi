from nmx_msg import Vec_pb2 as _Vec_pb2
from nmx_msg import Quaternion_pb2 as _Quaternion_pb2
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar, Mapping, Optional, Union

DESCRIPTOR: _descriptor.FileDescriptor

class Pose2(_message.Message):
    __slots__ = ["pos", "yaw"]
    POS_FIELD_NUMBER: ClassVar[int]
    YAW_FIELD_NUMBER: ClassVar[int]
    pos: _Vec_pb2.Vec2
    yaw: float
    def __init__(self, pos: Optional[Union[_Vec_pb2.Vec2, Mapping]] = ..., yaw: Optional[float] = ...) -> None: ...

class Pose3(_message.Message):
    __slots__ = ["pos", "quat"]
    POS_FIELD_NUMBER: ClassVar[int]
    QUAT_FIELD_NUMBER: ClassVar[int]
    pos: _Vec_pb2.Vec3
    quat: _Quaternion_pb2.Quaternion
    def __init__(self, pos: Optional[Union[_Vec_pb2.Vec3, Mapping]] = ..., quat: Optional[Union[_Quaternion_pb2.Quaternion, Mapping]] = ...) -> None: ...
