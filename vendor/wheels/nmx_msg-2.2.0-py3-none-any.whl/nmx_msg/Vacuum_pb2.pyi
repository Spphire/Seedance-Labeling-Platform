from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar, Iterable, Optional

DESCRIPTOR: _descriptor.FileDescriptor

class VacuumCommand(_message.Message):
    __slots__ = ["force", "index_list"]
    FORCE_FIELD_NUMBER: ClassVar[int]
    INDEX_LIST_FIELD_NUMBER: ClassVar[int]
    force: float
    index_list: _containers.RepeatedScalarFieldContainer[int]
    def __init__(self, index_list: Optional[Iterable[int]] = ..., force: Optional[float] = ...) -> None: ...

class VacuumState(_message.Message):
    __slots__ = ["force", "reach_target"]
    FORCE_FIELD_NUMBER: ClassVar[int]
    REACH_TARGET_FIELD_NUMBER: ClassVar[int]
    force: float
    reach_target: bool
    def __init__(self, reach_target: bool = ..., force: Optional[float] = ...) -> None: ...
