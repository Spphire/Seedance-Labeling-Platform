from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar, Optional, Union

BACKWARD: Direction
DESCRIPTOR: _descriptor.FileDescriptor
FORWARD: Direction
INVALIDDIRECTION: Direction
TURNLEFT: Direction
TURNRIGHT: Direction

class MoveAction(_message.Message):
    __slots__ = ["direction"]
    DIRECTION_FIELD_NUMBER: ClassVar[int]
    direction: Direction
    def __init__(self, direction: Optional[Union[Direction, str]] = ...) -> None: ...

class Direction(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = []
