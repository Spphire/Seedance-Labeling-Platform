from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar, Optional

DESCRIPTOR: _descriptor.FileDescriptor

class Status(_message.Message):
    __slots__ = ["code", "msg"]
    CODE_FIELD_NUMBER: ClassVar[int]
    MSG_FIELD_NUMBER: ClassVar[int]
    code: int
    msg: str
    def __init__(self, code: Optional[int] = ..., msg: Optional[str] = ...) -> None: ...
