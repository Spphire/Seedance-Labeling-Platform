from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar, Optional, Union

DESCRIPTOR: _descriptor.FileDescriptor

class TeleopCmd(_message.Message):
    __slots__ = ["mode", "peer_robot_id"]
    class Mode(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
        __slots__ = []
    JOINT: TeleopCmd.Mode
    MODE_FIELD_NUMBER: ClassVar[int]
    PEER_ROBOT_ID_FIELD_NUMBER: ClassVar[int]
    TCP: TeleopCmd.Mode
    UNKNOWN: TeleopCmd.Mode
    mode: TeleopCmd.Mode
    peer_robot_id: str
    def __init__(self, mode: Optional[Union[TeleopCmd.Mode, str]] = ..., peer_robot_id: Optional[str] = ...) -> None: ...

class TeleopState(_message.Message):
    __slots__ = ["is_ready"]
    IS_READY_FIELD_NUMBER: ClassVar[int]
    is_ready: bool
    def __init__(self, is_ready: bool = ...) -> None: ...
