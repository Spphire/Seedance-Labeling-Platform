from nmx_msg import Header_pb2 as _Header_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar, Iterable, Mapping, Optional, Union

DESCRIPTOR: _descriptor.FileDescriptor
ENCODED: ImageDataType
FLOAT32: ImageDataType
FLOAT64: ImageDataType
UINT16: ImageDataType
UINT32: ImageDataType
UINT8: ImageDataType

class Image(_message.Message):
    __slots__ = ["channels", "cols", "data", "encoded_format", "header", "rows", "step", "type"]
    CHANNELS_FIELD_NUMBER: ClassVar[int]
    COLS_FIELD_NUMBER: ClassVar[int]
    DATA_FIELD_NUMBER: ClassVar[int]
    ENCODED_FORMAT_FIELD_NUMBER: ClassVar[int]
    HEADER_FIELD_NUMBER: ClassVar[int]
    ROWS_FIELD_NUMBER: ClassVar[int]
    STEP_FIELD_NUMBER: ClassVar[int]
    TYPE_FIELD_NUMBER: ClassVar[int]
    channels: int
    cols: int
    data: bytes
    encoded_format: str
    header: _Header_pb2.Header
    rows: int
    step: int
    type: ImageDataType
    def __init__(self, header: Optional[Union[_Header_pb2.Header, Mapping]] = ..., rows: Optional[int] = ..., cols: Optional[int] = ..., channels: Optional[int] = ..., type: Optional[Union[ImageDataType, str]] = ..., step: Optional[int] = ..., data: Optional[bytes] = ..., encoded_format: Optional[str] = ...) -> None: ...

class ImageArray(_message.Message):
    __slots__ = ["images"]
    IMAGES_FIELD_NUMBER: ClassVar[int]
    images: _containers.RepeatedCompositeFieldContainer[Image]
    def __init__(self, images: Optional[Iterable[Union[Image, Mapping]]] = ...) -> None: ...

class RGBD(_message.Message):
    __slots__ = ["depth", "depth_scale", "rgb"]
    DEPTH_FIELD_NUMBER: ClassVar[int]
    DEPTH_SCALE_FIELD_NUMBER: ClassVar[int]
    RGB_FIELD_NUMBER: ClassVar[int]
    depth: Image
    depth_scale: float
    rgb: Image
    def __init__(self, rgb: Optional[Union[Image, Mapping]] = ..., depth: Optional[Union[Image, Mapping]] = ..., depth_scale: Optional[float] = ...) -> None: ...

class Stereo(_message.Message):
    __slots__ = ["left", "right"]
    LEFT_FIELD_NUMBER: ClassVar[int]
    RIGHT_FIELD_NUMBER: ClassVar[int]
    left: Image
    right: Image
    def __init__(self, left: Optional[Union[Image, Mapping]] = ..., right: Optional[Union[Image, Mapping]] = ...) -> None: ...

class ImageDataType(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = []
