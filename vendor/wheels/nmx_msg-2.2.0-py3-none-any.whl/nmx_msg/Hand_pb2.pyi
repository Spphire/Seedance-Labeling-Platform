from nmx_msg import Joint_pb2 as _Joint_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar, Iterable, Mapping, Optional, Union

DESCRIPTOR: _descriptor.FileDescriptor

class HandCmd(_message.Message):
    __slots__ = ["joints", "opts"]
    JOINTS_FIELD_NUMBER: ClassVar[int]
    OPTS_FIELD_NUMBER: ClassVar[int]
    joints: _containers.RepeatedCompositeFieldContainer[_Joint_pb2.JointCmd]
    opts: str
    def __init__(self, joints: Optional[Iterable[Union[_Joint_pb2.JointCmd, Mapping]]] = ..., opts: Optional[str] = ...) -> None: ...

class HandState(_message.Message):
    __slots__ = ["joints", "target_reached"]
    JOINTS_FIELD_NUMBER: ClassVar[int]
    TARGET_REACHED_FIELD_NUMBER: ClassVar[int]
    joints: _containers.RepeatedCompositeFieldContainer[_Joint_pb2.JointState]
    target_reached: bool
    def __init__(self, joints: Optional[Iterable[Union[_Joint_pb2.JointState, Mapping]]] = ..., target_reached: bool = ...) -> None: ...
