from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar, Optional

DESCRIPTOR: _descriptor.FileDescriptor

class Header(_message.Message):
    __slots__ = ["frame_id", "seq", "stamp"]
    FRAME_ID_FIELD_NUMBER: ClassVar[int]
    SEQ_FIELD_NUMBER: ClassVar[int]
    STAMP_FIELD_NUMBER: ClassVar[int]
    frame_id: str
    seq: int
    stamp: int
    def __init__(self, seq: Optional[int] = ..., stamp: Optional[int] = ..., frame_id: Optional[str] = ...) -> None: ...
