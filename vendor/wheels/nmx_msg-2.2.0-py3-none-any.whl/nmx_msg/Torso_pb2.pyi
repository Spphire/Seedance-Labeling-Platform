from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar, Optional

DESCRIPTOR: _descriptor.FileDescriptor

class TorsoCommand(_message.Message):
    __slots__ = ["pos", "vel"]
    POS_FIELD_NUMBER: ClassVar[int]
    VEL_FIELD_NUMBER: ClassVar[int]
    pos: float
    vel: float
    def __init__(self, pos: Optional[float] = ..., vel: Optional[float] = ...) -> None: ...
