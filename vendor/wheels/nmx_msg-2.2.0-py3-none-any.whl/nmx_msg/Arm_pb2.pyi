from nmx_msg import Joint_pb2 as _Joint_pb2
from nmx_msg import Pose_pb2 as _Pose_pb2
from nmx_msg import Vec_pb2 as _Vec_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar, Iterable, Mapping, Optional, Union

DESCRIPTOR: _descriptor.FileDescriptor

class ArmCmd(_message.Message):
    __slots__ = ["joints", "opts"]
    JOINTS_FIELD_NUMBER: ClassVar[int]
    OPTS_FIELD_NUMBER: ClassVar[int]
    joints: _containers.RepeatedCompositeFieldContainer[_Joint_pb2.JointCmd]
    opts: str
    def __init__(self, joints: Optional[Iterable[Union[_Joint_pb2.JointCmd, Mapping]]] = ..., opts: Optional[str] = ...) -> None: ...

class ArmEndForce(_message.Message):
    __slots__ = ["force", "torque"]
    FORCE_FIELD_NUMBER: ClassVar[int]
    TORQUE_FIELD_NUMBER: ClassVar[int]
    force: _Vec_pb2.Vec3
    torque: _Vec_pb2.Vec3
    def __init__(self, force: Optional[Union[_Vec_pb2.Vec3, Mapping]] = ..., torque: Optional[Union[_Vec_pb2.Vec3, Mapping]] = ...) -> None: ...

class ArmMethod(_message.Message):
    __slots__ = ["method"]
    class Method(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
        __slots__ = []
    CLEAR_FORCE_DATA: ArmMethod.Method
    METHOD_FIELD_NUMBER: ClassVar[int]
    UNKNOWN: ArmMethod.Method
    method: ArmMethod.Method
    def __init__(self, method: Optional[Union[ArmMethod.Method, str]] = ...) -> None: ...

class ArmState(_message.Message):
    __slots__ = ["joints"]
    JOINTS_FIELD_NUMBER: ClassVar[int]
    joints: _containers.RepeatedCompositeFieldContainer[_Joint_pb2.JointState]
    def __init__(self, joints: Optional[Iterable[Union[_Joint_pb2.JointState, Mapping]]] = ...) -> None: ...

class ArmTcpCmd(_message.Message):
    __slots__ = ["linear_vel", "opts", "pose"]
    LINEAR_VEL_FIELD_NUMBER: ClassVar[int]
    OPTS_FIELD_NUMBER: ClassVar[int]
    POSE_FIELD_NUMBER: ClassVar[int]
    linear_vel: float
    opts: str
    pose: _Pose_pb2.Pose3
    def __init__(self, pose: Optional[Union[_Pose_pb2.Pose3, Mapping]] = ..., linear_vel: Optional[float] = ..., opts: Optional[str] = ...) -> None: ...

class ArmTcpState(_message.Message):
    __slots__ = ["angular_vel", "linear_vel", "pose"]
    ANGULAR_VEL_FIELD_NUMBER: ClassVar[int]
    LINEAR_VEL_FIELD_NUMBER: ClassVar[int]
    POSE_FIELD_NUMBER: ClassVar[int]
    angular_vel: _Vec_pb2.Vec3
    linear_vel: _Vec_pb2.Vec3
    pose: _Pose_pb2.Pose3
    def __init__(self, pose: Optional[Union[_Pose_pb2.Pose3, Mapping]] = ..., linear_vel: Optional[Union[_Vec_pb2.Vec3, Mapping]] = ..., angular_vel: Optional[Union[_Vec_pb2.Vec3, Mapping]] = ...) -> None: ...

class ArmTeachCmd(_message.Message):
    __slots__ = ["dir", "step", "vel"]
    class Direction(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
        __slots__ = []
    DIR_FIELD_NUMBER: ClassVar[int]
    RX: ArmTeachCmd.Direction
    RY: ArmTeachCmd.Direction
    RZ: ArmTeachCmd.Direction
    STEP_FIELD_NUMBER: ClassVar[int]
    UNKNOWN: ArmTeachCmd.Direction
    VEL_FIELD_NUMBER: ClassVar[int]
    X: ArmTeachCmd.Direction
    Y: ArmTeachCmd.Direction
    Z: ArmTeachCmd.Direction
    dir: ArmTeachCmd.Direction
    step: float
    vel: float
    def __init__(self, dir: Optional[Union[ArmTeachCmd.Direction, str]] = ..., step: Optional[float] = ..., vel: Optional[float] = ...) -> None: ...
