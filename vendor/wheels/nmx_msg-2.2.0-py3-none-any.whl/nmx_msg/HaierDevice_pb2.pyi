from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar, Optional

DESCRIPTOR: _descriptor.FileDescriptor

class HaierDeviceStatus(_message.Message):
    __slots__ = ["device_online", "door_locked"]
    DEVICE_ONLINE_FIELD_NUMBER: ClassVar[int]
    DOOR_LOCKED_FIELD_NUMBER: ClassVar[int]
    device_online: bool
    door_locked: bool
    def __init__(self, device_online: bool = ..., door_locked: bool = ...) -> None: ...
