from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar, Iterable, Optional

DESCRIPTOR: _descriptor.FileDescriptor

class CameraExtrinsic(_message.Message):
    __slots__ = ["camera_id", "error", "is_global", "parent_link_name", "pose_in_link"]
    CAMERA_ID_FIELD_NUMBER: ClassVar[int]
    ERROR_FIELD_NUMBER: ClassVar[int]
    IS_GLOBAL_FIELD_NUMBER: ClassVar[int]
    PARENT_LINK_NAME_FIELD_NUMBER: ClassVar[int]
    POSE_IN_LINK_FIELD_NUMBER: ClassVar[int]
    camera_id: str
    error: float
    is_global: bool
    parent_link_name: str
    pose_in_link: _containers.RepeatedScalarFieldContainer[float]
    def __init__(self, camera_id: Optional[str] = ..., is_global: bool = ..., pose_in_link: Optional[Iterable[float]] = ..., error: Optional[float] = ..., parent_link_name: Optional[str] = ...) -> None: ...

class CameraIntrinsic(_message.Message):
    __slots__ = ["cx", "cy", "depth_scale", "distortion", "fx", "fy", "height", "width"]
    CX_FIELD_NUMBER: ClassVar[int]
    CY_FIELD_NUMBER: ClassVar[int]
    DEPTH_SCALE_FIELD_NUMBER: ClassVar[int]
    DISTORTION_FIELD_NUMBER: ClassVar[int]
    FX_FIELD_NUMBER: ClassVar[int]
    FY_FIELD_NUMBER: ClassVar[int]
    HEIGHT_FIELD_NUMBER: ClassVar[int]
    WIDTH_FIELD_NUMBER: ClassVar[int]
    cx: float
    cy: float
    depth_scale: float
    distortion: _containers.RepeatedScalarFieldContainer[float]
    fx: float
    fy: float
    height: float
    width: float
    def __init__(self, fx: Optional[float] = ..., fy: Optional[float] = ..., cx: Optional[float] = ..., cy: Optional[float] = ..., width: Optional[float] = ..., height: Optional[float] = ..., depth_scale: Optional[float] = ..., distortion: Optional[Iterable[float]] = ...) -> None: ...

class CameraStatus(_message.Message):
    __slots__ = ["fps", "healthy"]
    FPS_FIELD_NUMBER: ClassVar[int]
    HEALTHY_FIELD_NUMBER: ClassVar[int]
    fps: float
    healthy: bool
    def __init__(self, healthy: bool = ..., fps: Optional[float] = ...) -> None: ...
