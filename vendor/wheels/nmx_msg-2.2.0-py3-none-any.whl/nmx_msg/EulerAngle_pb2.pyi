from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar, Optional

DESCRIPTOR: _descriptor.FileDescriptor

class EulerAngle(_message.Message):
    __slots__ = ["pitch", "roll", "yaw"]
    PITCH_FIELD_NUMBER: ClassVar[int]
    ROLL_FIELD_NUMBER: ClassVar[int]
    YAW_FIELD_NUMBER: ClassVar[int]
    pitch: float
    roll: float
    yaw: float
    def __init__(self, yaw: Optional[float] = ..., pitch: Optional[float] = ..., roll: Optional[float] = ...) -> None: ...
