from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar, Optional

DESCRIPTOR: _descriptor.FileDescriptor

class SystemState(_message.Message):
    __slots__ = ["cpu_load", "disk_total", "disk_usage", "gpu_load", "memory_total", "memory_usage"]
    CPU_LOAD_FIELD_NUMBER: ClassVar[int]
    DISK_TOTAL_FIELD_NUMBER: ClassVar[int]
    DISK_USAGE_FIELD_NUMBER: ClassVar[int]
    GPU_LOAD_FIELD_NUMBER: ClassVar[int]
    MEMORY_TOTAL_FIELD_NUMBER: ClassVar[int]
    MEMORY_USAGE_FIELD_NUMBER: ClassVar[int]
    cpu_load: float
    disk_total: float
    disk_usage: float
    gpu_load: float
    memory_total: float
    memory_usage: float
    def __init__(self, disk_usage: Optional[float] = ..., cpu_load: Optional[float] = ..., memory_usage: Optional[float] = ..., gpu_load: Optional[float] = ..., disk_total: Optional[float] = ..., memory_total: Optional[float] = ...) -> None: ...
