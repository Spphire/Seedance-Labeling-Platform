from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar, Optional

DESCRIPTOR: _descriptor.FileDescriptor

class IRSensorState(_message.Message):
    __slots__ = ["blocked"]
    BLOCKED_FIELD_NUMBER: ClassVar[int]
    blocked: bool
    def __init__(self, blocked: bool = ...) -> None: ...
