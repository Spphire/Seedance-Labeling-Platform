from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar, Optional

DESCRIPTOR: _descriptor.FileDescriptor

class JointCmd(_message.Message):
    __slots__ = ["acc", "effort", "name", "pos", "vel"]
    ACC_FIELD_NUMBER: ClassVar[int]
    EFFORT_FIELD_NUMBER: ClassVar[int]
    NAME_FIELD_NUMBER: ClassVar[int]
    POS_FIELD_NUMBER: ClassVar[int]
    VEL_FIELD_NUMBER: ClassVar[int]
    acc: float
    effort: float
    name: str
    pos: float
    vel: float
    def __init__(self, name: Optional[str] = ..., pos: Optional[float] = ..., vel: Optional[float] = ..., acc: Optional[float] = ..., effort: Optional[float] = ...) -> None: ...

class JointState(_message.Message):
    __slots__ = ["acc", "effort", "name", "pos", "vel"]
    ACC_FIELD_NUMBER: ClassVar[int]
    EFFORT_FIELD_NUMBER: ClassVar[int]
    NAME_FIELD_NUMBER: ClassVar[int]
    POS_FIELD_NUMBER: ClassVar[int]
    VEL_FIELD_NUMBER: ClassVar[int]
    acc: float
    effort: float
    name: str
    pos: float
    vel: float
    def __init__(self, name: Optional[str] = ..., pos: Optional[float] = ..., vel: Optional[float] = ..., acc: Optional[float] = ..., effort: Optional[float] = ...) -> None: ...
