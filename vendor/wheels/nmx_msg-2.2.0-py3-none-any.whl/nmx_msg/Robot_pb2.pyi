from google.protobuf.internal import containers as _containers
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar, Mapping, Optional, Union

DESCRIPTOR: _descriptor.FileDescriptor

class DeviceList(_message.Message):
    __slots__ = ["list"]
    class ListEntry(_message.Message):
        __slots__ = ["key", "value"]
        KEY_FIELD_NUMBER: ClassVar[int]
        VALUE_FIELD_NUMBER: ClassVar[int]
        key: str
        value: bool
        def __init__(self, key: Optional[str] = ..., value: bool = ...) -> None: ...
    LIST_FIELD_NUMBER: ClassVar[int]
    list: _containers.ScalarMap[str, bool]
    def __init__(self, list: Optional[Mapping[str, bool]] = ...) -> None: ...

class RobotCmd(_message.Message):
    __slots__ = ["method"]
    class Method(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
        __slots__ = []
    DISABLE: RobotCmd.Method
    ENABLE: RobotCmd.Method
    METHOD_FIELD_NUMBER: ClassVar[int]
    STOP: RobotCmd.Method
    UNKNOWN: RobotCmd.Method
    method: RobotCmd.Method
    def __init__(self, method: Optional[Union[RobotCmd.Method, str]] = ...) -> None: ...

class RobotUrdf(_message.Message):
    __slots__ = ["content", "name"]
    CONTENT_FIELD_NUMBER: ClassVar[int]
    NAME_FIELD_NUMBER: ClassVar[int]
    content: bytes
    name: str
    def __init__(self, name: Optional[str] = ..., content: Optional[bytes] = ...) -> None: ...
