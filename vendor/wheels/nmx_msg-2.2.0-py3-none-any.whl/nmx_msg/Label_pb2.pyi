from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar, Optional

DESCRIPTOR: _descriptor.FileDescriptor

class CommonLabel(_message.Message):
    __slots__ = ["annotation_format", "data", "schema_version"]
    ANNOTATION_FORMAT_FIELD_NUMBER: ClassVar[int]
    DATA_FIELD_NUMBER: ClassVar[int]
    SCHEMA_VERSION_FIELD_NUMBER: ClassVar[int]
    annotation_format: str
    data: bytes
    schema_version: str
    def __init__(self, annotation_format: Optional[str] = ..., schema_version: Optional[str] = ..., data: Optional[bytes] = ...) -> None: ...
