from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar, Optional

DESCRIPTOR: _descriptor.FileDescriptor

class Metadata(_message.Message):
    __slots__ = ["metadata", "version"]
    METADATA_FIELD_NUMBER: ClassVar[int]
    VERSION_FIELD_NUMBER: ClassVar[int]
    metadata: bytes
    version: str
    def __init__(self, version: Optional[str] = ..., metadata: Optional[bytes] = ...) -> None: ...
