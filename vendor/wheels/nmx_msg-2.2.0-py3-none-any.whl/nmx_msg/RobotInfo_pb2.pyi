from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar, Optional

DESCRIPTOR: _descriptor.FileDescriptor

class RobotInfo(_message.Message):
    __slots__ = ["id", "name", "type"]
    ID_FIELD_NUMBER: ClassVar[int]
    NAME_FIELD_NUMBER: ClassVar[int]
    TYPE_FIELD_NUMBER: ClassVar[int]
    id: str
    name: str
    type: str
    def __init__(self, name: Optional[str] = ..., type: Optional[str] = ..., id: Optional[str] = ...) -> None: ...
