from nmx_msg import Vec_pb2 as _Vec_pb2
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar, Mapping, Optional, Union

DESCRIPTOR: _descriptor.FileDescriptor

class BoundingBox2(_message.Message):
    __slots__ = ["max", "min"]
    MAX_FIELD_NUMBER: ClassVar[int]
    MIN_FIELD_NUMBER: ClassVar[int]
    max: _Vec_pb2.Vec2
    min: _Vec_pb2.Vec2
    def __init__(self, min: Optional[Union[_Vec_pb2.Vec2, Mapping]] = ..., max: Optional[Union[_Vec_pb2.Vec2, Mapping]] = ...) -> None: ...

class BoundingBox3(_message.Message):
    __slots__ = ["max", "min"]
    MAX_FIELD_NUMBER: ClassVar[int]
    MIN_FIELD_NUMBER: ClassVar[int]
    max: _Vec_pb2.Vec3
    min: _Vec_pb2.Vec3
    def __init__(self, min: Optional[Union[_Vec_pb2.Vec3, Mapping]] = ..., max: Optional[Union[_Vec_pb2.Vec3, Mapping]] = ...) -> None: ...
