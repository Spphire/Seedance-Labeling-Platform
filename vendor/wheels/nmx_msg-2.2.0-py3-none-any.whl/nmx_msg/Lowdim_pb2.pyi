from google.protobuf.internal import containers as _containers
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar, Iterable, Mapping, Optional, Union

DESCRIPTOR: _descriptor.FileDescriptor
DEVICE_ERROR: StateCode
ENCODER_BROKEN: StateCode
INPUT_ERROR: StateCode
OK: StateCode
OTHER_ERROR: StateCode
STATE_ERROR: StateCode
THREAD_ERROR: StateCode
USB_ERROR: StateCode
WAITTING: StateCode

class Arm(_message.Message):
    __slots__ = ["arm_id", "flange_pose", "joint_acc", "joint_pose", "joint_vel", "state_code", "tcp_pose", "tcp_vel"]
    ARM_ID_FIELD_NUMBER: ClassVar[int]
    FLANGE_POSE_FIELD_NUMBER: ClassVar[int]
    JOINT_ACC_FIELD_NUMBER: ClassVar[int]
    JOINT_POSE_FIELD_NUMBER: ClassVar[int]
    JOINT_VEL_FIELD_NUMBER: ClassVar[int]
    STATE_CODE_FIELD_NUMBER: ClassVar[int]
    TCP_POSE_FIELD_NUMBER: ClassVar[int]
    TCP_VEL_FIELD_NUMBER: ClassVar[int]
    arm_id: int
    flange_pose: _containers.RepeatedScalarFieldContainer[float]
    joint_acc: _containers.RepeatedScalarFieldContainer[float]
    joint_pose: _containers.RepeatedScalarFieldContainer[float]
    joint_vel: _containers.RepeatedScalarFieldContainer[float]
    state_code: StateCode
    tcp_pose: _containers.RepeatedScalarFieldContainer[float]
    tcp_vel: _containers.RepeatedScalarFieldContainer[float]
    def __init__(self, joint_pose: Optional[Iterable[float]] = ..., joint_vel: Optional[Iterable[float]] = ..., joint_acc: Optional[Iterable[float]] = ..., flange_pose: Optional[Iterable[float]] = ..., tcp_pose: Optional[Iterable[float]] = ..., tcp_vel: Optional[Iterable[float]] = ..., arm_id: Optional[int] = ..., state_code: Optional[Union[StateCode, str]] = ...) -> None: ...

class EndTool(_message.Message):
    __slots__ = ["arm_id", "joint_pose", "state_code"]
    ARM_ID_FIELD_NUMBER: ClassVar[int]
    JOINT_POSE_FIELD_NUMBER: ClassVar[int]
    STATE_CODE_FIELD_NUMBER: ClassVar[int]
    arm_id: int
    joint_pose: _containers.RepeatedScalarFieldContainer[float]
    state_code: StateCode
    def __init__(self, joint_pose: Optional[Iterable[float]] = ..., arm_id: Optional[int] = ..., state_code: Optional[Union[StateCode, str]] = ...) -> None: ...

class EndToolStatus(_message.Message):
    __slots__ = ["data", "meta"]
    DATA_FIELD_NUMBER: ClassVar[int]
    META_FIELD_NUMBER: ClassVar[int]
    data: _containers.RepeatedCompositeFieldContainer[EndTool]
    meta: str
    def __init__(self, data: Optional[Iterable[Union[EndTool, Mapping]]] = ..., meta: Optional[str] = ...) -> None: ...

class Lowdim(_message.Message):
    __slots__ = ["airexo_ee", "airexo_joint", "ee_command", "ee_state", "joint", "tcp"]
    AIREXO_EE_FIELD_NUMBER: ClassVar[int]
    AIREXO_JOINT_FIELD_NUMBER: ClassVar[int]
    EE_COMMAND_FIELD_NUMBER: ClassVar[int]
    EE_STATE_FIELD_NUMBER: ClassVar[int]
    JOINT_FIELD_NUMBER: ClassVar[int]
    TCP_FIELD_NUMBER: ClassVar[int]
    airexo_ee: _containers.RepeatedScalarFieldContainer[float]
    airexo_joint: _containers.RepeatedScalarFieldContainer[float]
    ee_command: _containers.RepeatedScalarFieldContainer[float]
    ee_state: _containers.RepeatedScalarFieldContainer[float]
    joint: _containers.RepeatedScalarFieldContainer[float]
    tcp: _containers.RepeatedScalarFieldContainer[float]
    def __init__(self, airexo_joint: Optional[Iterable[float]] = ..., airexo_ee: Optional[Iterable[float]] = ..., ee_command: Optional[Iterable[float]] = ..., tcp: Optional[Iterable[float]] = ..., joint: Optional[Iterable[float]] = ..., ee_state: Optional[Iterable[float]] = ...) -> None: ...

class LowdimData(_message.Message):
    __slots__ = ["data", "object_count"]
    DATA_FIELD_NUMBER: ClassVar[int]
    OBJECT_COUNT_FIELD_NUMBER: ClassVar[int]
    data: _containers.RepeatedScalarFieldContainer[float]
    object_count: int
    def __init__(self, data: Optional[Iterable[float]] = ..., object_count: Optional[int] = ...) -> None: ...

class LowdimMessage(_message.Message):
    __slots__ = ["lowdim_data", "state_code"]
    LOWDIM_DATA_FIELD_NUMBER: ClassVar[int]
    STATE_CODE_FIELD_NUMBER: ClassVar[int]
    lowdim_data: LowdimData
    state_code: StateCode
    def __init__(self, lowdim_data: Optional[Union[LowdimData, Mapping]] = ..., state_code: Optional[Union[StateCode, str]] = ...) -> None: ...

class RobotStatus(_message.Message):
    __slots__ = ["data", "meta"]
    DATA_FIELD_NUMBER: ClassVar[int]
    META_FIELD_NUMBER: ClassVar[int]
    data: _containers.RepeatedCompositeFieldContainer[Arm]
    meta: str
    def __init__(self, data: Optional[Iterable[Union[Arm, Mapping]]] = ..., meta: Optional[str] = ...) -> None: ...

class StateCode(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = []
